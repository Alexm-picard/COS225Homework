public interface InterestEligible{
    public abstract void applyInterest();
}